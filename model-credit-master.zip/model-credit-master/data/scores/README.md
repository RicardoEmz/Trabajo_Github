Dataset for Scoring
